const express = require('express');
const app = express();
const port = 300;

app.use(express.json());

app.listen(port, ()=>{
    console.log('Servidor ejecutandose en http:localhost:${port}');
});

let tareas = [];
let idActual = 1;

//Crear tareas
app.post('/tareas', (req, res)=>{
    const = nuevaTarea = {
        id: idActual++,
        titulo: req.body.titulo,
        descripcion: req.body.descripcion,
        completada: false,
        fechaCreacion: new Date()
    };
    tareas.push(nuevaTarea);
    res.status(201).json(nuevaTarea);
})

//Leer tareas
app.get('/tareas', (req,res)=>{
    res.json(tareas);
})

//Leer una tarea por su id
app.get('/tareas/:id', (req, res)=>{
    const tarea = tareas.find(t => t.id === parseInt(req.params.id));
    if(!tareas){
        return res.status(404).json({error:'Tarea no encontrada'});
    }
    res.json(tarea);
})

//Actualizar tareas
app.put('/tareas/:id',(req,res)=>{
    const tarea = tareas.find(t=>t.id===parseInt(req.params.id));
    if(!tarea){
        return res.status(404).json({error:'Tarea no encontrada'});
    }
    tarea.titulo=req.body.titulo || tarea.titulo;
    tarea.descripcion = req.body.descripcion || tarea.descripcion;
    tarea.completada=req.body.completada !== undefined ? req.body.completada : tarea.completada;
    res.json(tarea);
})

//Eliminar tareas
app.delete('/tareas/:id', (req,res)=>{
    const tareaIndex = tareas.findIndex(t=> t.id === parseInt(req.params.id));
    if(tareaIndex === -1){
        return res.status(404).json({error:'Tarea no encontrada'});
    }
    tareas.splice(tareaIndex,1);
    res.status(204).send();
});

app.get('/tareas/estadisticas',(req,res)=>{
    const totalTareas = tareas.length;
    const tareasCompletadas = tareas.filter(t=>t.completada).length;
    const tareasPendientes = totalTareas - tareasCompletadas;
    
    res.json({
        totalTareas,
        tareasCompletadas,
        tareasPendientes,
    });
});